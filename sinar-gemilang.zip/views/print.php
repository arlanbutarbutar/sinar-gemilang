<?php require_once("../controller/script.php");
require_once("redirect.php");
$_SESSION['page-name'] = "Print";
$_SESSION['page-url'] = "print";
?>

<!DOCTYPE html>
<html lang="en">

<head>

  <style>
    .cardWrap {
      width: 27em;
      margin: 3em auto;
      color: #fff;
      font-family: sans-serif;
    }

    .card-tiket {
      background: linear-gradient(to bottom, #009688 0%, #009688 26%, #ecedef 26%, #ecedef 100%);
      height: 11em;
      float: left;
      position: relative;
      padding: 1em;
      margin-top: 100px;
    }

    .cardLeft {
      border-top-left-radius: 8px;
      border-bottom-left-radius: 8px;
      width: 16em;
    }

    .cardRight {
      width: 6.5em;
      border-left: 0.18em dashed #fff;
      border-top-right-radius: 8px;
      border-bottom-right-radius: 8px;
    }

    .cardRight:before,
    .cardRight:after {
      content: "";
      position: absolute;
      display: block;
      width: 0.9em;
      height: 0.9em;
      background: #fff;
      border-radius: 50%;
      left: -0.5em;
    }

    .cardRight:before {
      top: -0.4em;
    }

    .cardRight:after {
      bottom: -0.4em;
    }

    .nama-bus {
      font-size: 1.1em;
      margin-top: 0;
    }

    .nama-bus span {
      font-weight: normal;
    }

    .title-tiket,
    .name-tiket,
    .seat-tiket,
    .time-tiket {
      text-transform: uppercase;
      font-weight: normal;
    }

    .title-tiket h2,
    .name-tiket h2,
    .seat-tiket h2,
    .time-tiket h2 {
      font-size: 0.9em;
      color: #525252;
      margin: 0;
    }

    .title-tiket span,
    .name-tiket span,
    .seat-tiket span,
    .time-tiket span {
      font-size: 0.7em;
      color: #a2aeae;
    }

    .title-tiket {
      margin: 2em 0 0 0;
    }

    .name-tiket,
    .seat-tiket {
      margin: 0.7em 0 0 0;
    }

    .time-tiket {
      margin: 0.7em 0 0 1em;
    }

    .seat-tiket,
    .time-tiket {
      float: left;
    }

    .eye-tiket {
      position: relative;
      width: 2em;
      height: 1.5em;
      background: #fff;
      margin: 0 auto;
      border-radius: 1em/0.6em;
      z-index: 1;
    }

    .eye-tiket:before,
    .eye-tiket:after {
      content: "";
      display: block;
      position: absolute;
      border-radius: 50%;
    }

    .eye-tiket:before {
      width: 1em;
      height: 1em;
      background: #009688;
      z-index: 2;
      left: 8px;
      top: 4px;
    }

    .eye-tiket:after {
      width: 0.5em;
      height: 0.5em;
      background: #fff;
      z-index: 3;
      left: 12px;
      top: 8px;
    }

    .number-tiket {
      text-align: center;
      text-transform: uppercase;
    }

    .number-tiket h3 {
      color: #009688;
      margin: 0.9em 0 0 0;
      font-size: 2.5em;
    }

    .number-tiket span {
      display: block;
      color: #a2aeae;
    }
  </style>
  <script>window.print();</script>
</head>

<body>
  <div class="cardWrap" style="height: 50px;margin-top: -100px;">
    <div class="card-tiket cardLeft" style="height: 220px;">
      <h1 class="nama-bus">Sinar <span>Gemilang</span></h1>
      <div class="d-flex justify-content-between">
        <div class="title-tiket" style="margin-left: 30px;">
          <h2><strong><?= $row['nama_bus'] ?></strong><br>
            <div style="font-size: 10px;"><?= $row['no_plat'] ?></div>
          </h2>
          <span>Bus</span>
        </div>
        <div class="name-tiket" style="margin-right: 30px;margin-top: 32px;">
          <h2><strong><?= $row['username'] ?></strong></h2>
          <span>Nama</span>
        </div>
      </div>
      <div class="seat-tiket" style="text-align: left;">
        <h2><strong><?= $row['rute_dari'] . " - " . $row['rute_ke'] ?></strong></h2>
        <span>Tujuan</span>
      </div><br>
      <div class="time-tiket" style="margin-left: 0;text-align: left;">
        <h2><strong><?php $tglJln = date_create($row['tgl_jalan']);
                    echo date_format($tglJln, "d M Y") . " - " . $row['waktu_jalan'] ?></strong></h2>
        <span>Waktu</span>
      </div>
    </div>
    <div class="card-tiket cardRight" style="height: 220px;">
      <div class="eye-tiket"></div>
      <div class="number-tiket">
        <h3><?= $row['kursi'] ?></h3>
        <span>Kursi</span>
      </div>
    </div>
  </div>
</body>

</html>