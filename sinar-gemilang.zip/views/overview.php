<?php require_once("../controller/script.php"); ?>
<div class="container m-0 p-0">
  <div class="row">
    
  </div>
</div>