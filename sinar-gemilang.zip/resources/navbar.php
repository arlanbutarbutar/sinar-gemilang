<div id="mySidepanel" class="sidepanel">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">×</a>
  <a href="./">Beranda</a>
  <a href="auth/">Masuk</a>
</div>
<!-- header -->
<header>
  <!-- header inner -->
  <div class="header">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-4 col-sm-4">
          <div class="logo">
            <h1 class="font-weight-bold">Sinar Gemilang</h1>
          </div>
        </div>
        <div class="col-md-8 col-sm-8">
          <div class="right_bottun">
            <button class="openbtn" onclick="openNav()"><img src="assets/images/menu_icon.png" alt="#" width="30" /></button>
          </div>
        </div>
      </div>
    </div>
  </div>
</header>